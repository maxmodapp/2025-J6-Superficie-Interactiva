// Guardar como: Documentos/Arduino/libraries/CoM_Scale/CoM_Scale.cpp
#include "CoM_Scale.h"

// ================= Geometría (R = 46 mm => 460 dm) =================
// Triángulo: (0, +46), (-39.836, -23), (+39.836, -23) mm
// Redondeo a deci-mm: (0,460), (-398, -230), (398, -230)
const Vec2dm CoM_Scale::_POS1 = {    0,  460 };
const Vec2dm CoM_Scale::_POS2 = { -398, -230 };
const Vec2dm CoM_Scale::_POS3 = {  398, -230 };

// Ganancias Q10 (1024 = 1.000). Ajustá si una galga mide de más/menos.
const uint16_t CoM_Scale::_GAIN1_Q10 = 1024;
const uint16_t CoM_Scale::_GAIN2_Q10 = 1024;
const uint16_t CoM_Scale::_GAIN3_Q10 = 1024;

// ---------------- Implementación ----------------
CoM_Scale::CoM_Scale(uint8_t pin_sck, uint8_t pin_dt1, uint8_t pin_dt2, uint8_t pin_dt3)
  : _sck(pin_sck), _dt1(pin_dt1), _dt2(pin_dt2), _dt3(pin_dt3)
{
  _res = { false, false, 0, 0, 0, 0 };
  _ultimoValido = _res;
}

void ICACHE_FLASH_ATTR CoM_Scale::begin() {
  _hx1.begin(_dt1, _sck);
  _hx2.begin(_dt2, _sck);
  _hx3.begin(_dt3, _sck);

  _autoTareAll(30);

  _res = { false, false, 0, 0, 0, 0 };
  _ultimoValido = _res;

  Serial.println(F("\n[CoM_Scale] Init OK. TARE hecho."));
}

bool ICACHE_FLASH_ATTR CoM_Scale::update() {
  Lecturas lect;
  _leerHX711s(lect);
  _calcularCoM(lect);
  return _res.valido;
}

const Resultado& ICACHE_FLASH_ATTR CoM_Scale::getResultado() const {
  return _res;
}

// --- Privados ---
void ICACHE_FLASH_ATTR CoM_Scale::_leerHX711s(Lecturas &lect) {
  lect.r1 = _readTicks(_hx1);
  lect.r2 = _readTicks(_hx2);
  lect.r3 = _readTicks(_hx3);
}

void ICACHE_FLASH_ATTR CoM_Scale::_calcularCoM(const Lecturas &L) {
  // Ponderación con ganancias Q10 sin usar float
  int32_t w1 = ( (int64_t)L.r1 * _GAIN1_Q10 ) >> _GAIN_SHIFT;
  int32_t w2 = ( (int64_t)L.r2 * _GAIN2_Q10 ) >> _GAIN_SHIFT;
  int32_t w3 = ( (int64_t)L.r3 * _GAIN3_Q10 ) >> _GAIN_SHIFT;

  int32_t sum_signed = w1 + w2 + w3;

  // sum_abs y sum_comp (solo positivos) sin float
  int32_t a1 = (w1 >= 0) ?  w1 : -w1;
  int32_t a2 = (w2 >= 0) ?  w2 : -w2;
  int32_t a3 = (w3 >= 0) ?  w3 : -w3;
  int32_t sum_abs = a1 + a2 + a3;

  int32_t c1 = (w1 > 0) ? w1 : 0;
  int32_t c2 = (w2 > 0) ? w2 : 0;
  int32_t c3 = (w3 > 0) ? w3 : 0;
  int32_t sum_comp = c1 + c2 + c3;

  const int32_t MIN_ABS_SUM = 1500; // “hay peso”
  const int32_t EPS_SIGNED  = 1;    // evitar división por 0

  bool hayCarga = (sum_abs >= MIN_ABS_SUM);
  bool estable  = (sum_signed > EPS_SIGNED || sum_signed < -EPS_SIGNED);

  _res.valido       = hayCarga && estable;
  _res.extrapolando = (w1 < 0 || w2 < 0 || w3 < 0);

  if (_res.valido) {
    // Numeradores en deci-mm (usar 64 bits para no saturar)
    int64_t Xnum = (int64_t)w1 * _POS1.x_dm + (int64_t)w2 * _POS2.x_dm + (int64_t)w3 * _POS3.x_dm;
    int64_t Ynum = (int64_t)w1 * _POS1.y_dm + (int64_t)w2 * _POS2.y_dm + (int64_t)w3 * _POS3.y_dm;

    // División entera → deci-mm
    _res.x_dm = (int16_t)( Xnum / (int64_t)sum_signed );
    _res.y_dm = (int16_t)( Ynum / (int64_t)sum_signed );

    _res.total_signed = sum_signed;
    _res.total_comp   = sum_comp;

    _ultimoValido = _res;
  } else {
    _res = _ultimoValido;
  }
}

void ICACHE_FLASH_ATTR CoM_Scale::_autoTareAll(int avg) {
  delay(500);
  _hx1.tare(avg);
  _hx2.tare(avg);
  _hx3.tare(avg);
}

int32_t ICACHE_FLASH_ATTR CoM_Scale::_readTicks(HX711 &hx) {
  const uint8_t N_SAMPLES = 10;
  return (int32_t)(hx.read_average(N_SAMPLES) - hx.get_offset());
}
