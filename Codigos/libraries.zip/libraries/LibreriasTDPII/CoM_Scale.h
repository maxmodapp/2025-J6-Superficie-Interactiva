// Guardar como: Documentos/Arduino/libraries/CoM_Scale/CoM_Scale.h
#ifndef COM_SCALE_H
#define COM_SCALE_H

#include <Arduino.h>
#include "HX711.h"

// Posiciones en deci-milímetros (dm): 1 dm = 0.1 mm
// Ej.: 46.0 mm -> 460 dm
struct Vec2dm {
  int16_t x_dm;
  int16_t y_dm;
};

struct Resultado {
  bool     valido;
  bool     extrapolando;
  int16_t  x_dm;            // CoM X en deci-mm
  int16_t  y_dm;            // CoM Y en deci-mm
  int32_t  total_signed;    // suma firmada (ticks ponderados)
  int32_t  total_comp;      // suma compresiva (solo positivos)
};

class CoM_Scale {
public:
  CoM_Scale(uint8_t pin_sck, uint8_t pin_dt1, uint8_t pin_dt2, uint8_t pin_dt3);

  void begin();         // inicializa y hace TARE
  bool update();        // lee sensores y calcula CoM (true si válido)
  const Resultado& getResultado() const;

private:
  // --- Objetos y pines ---
  HX711   _hx1, _hx2, _hx3;
  uint8_t _sck, _dt1, _dt2, _dt3;

  // --- Geometría (en deci-mm) ---
  static const Vec2dm _POS1, _POS2, _POS3;

  // --- Ganancias enteras Q10 (1.000 = 1024) para balancear galgas ---
  static const uint16_t _GAIN1_Q10;
  static const uint16_t _GAIN2_Q10;
  static const uint16_t _GAIN3_Q10;
  static const uint8_t  _GAIN_SHIFT = 10; // >> 10

  // --- Datos internos ---
  struct Lecturas { int32_t r1, r2, r3; };
  Resultado _res, _ultimoValido;

  // --- Lógica interna ---
  void _leerHX711s(Lecturas &lect);
  void _calcularCoM(const Lecturas &lect);
  void _autoTareAll(int avg = 25);
  int32_t _readTicks(HX711 &hx);
};

#endif
